<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-3">
    <!-- Profile Image -->
    <div class="box box-primary">
      <div class="box-body box-profile">
          <a href="<?php echo e(route('remove_picture_project',['project_id'=>$project->id])); ?>">
              <i class="fa fa-lg fa-remove delete_image_profile"> </i>
          </a>
         <div class="image-box">
            <?php if(!empty($project->image) && isset($project->image)): ?>

            <img src="<?php echo e(asset('public/storage/project-images/'. $project->image)); ?>" style="height:160px; width:160px" class="profile-user-img img-responsive img-circle">
            <?php else: ?>
            <img src="<?php echo e(asset('public/storage/project-images/default1.png')); ?>" style="height:160px; width:160px" class="profile-user-img img-responsive img-circle">
            <?php endif; ?>
            <form action="<?php echo e(route('ImageUploadProject')); ?>" method="post" enctype="multipart/form-data" id="change_admin_profile_pic">
                  <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden">
                  <input name="project_id" value="<?php echo e($project->id); ?>" type="hidden">
            <div class="camera_image">
              <i class="fa fa-camera fa-2x" aria-hidden="true"></i>
              <input name="image" id="change_admin_profile_pic" type="file">
            </div>
          </form>
        </div>              
        <h3 class="profile-username text-center"><?php echo e($project->name); ?></h3>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>        
  <!-- /.col -->
  <div class="col-md-9">
    <div class="nav-tabs-custom">
      <ul class="nav nav-tabs">
        <li class="active"><a href="#settings" data-toggle="tab" aria-expanded="true">Project Information</a></li>
      </ul>
      <div class="tab-content">
        <!-- /.tab-pane -->
        <div class="tab-pane active" id="settings">
          <form class="form-horizontal">
            <div class="form-group">
              <label for="inputName" class="col-sm-2 control-label">Title:</label>
              <div class="col-sm-10">
               <p> <?php echo e($project->title); ?> </p>
              </div>
            </div>
            <div class="form-group">
              <label for="inputName" class="col-sm-2 control-label">Description:</label>
              <div class="col-sm-10">
               <p><?php echo e($project->description); ?></p>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12" style="margin-left: 100px;">                      
                  <a href="<?php echo e(route('project_edit',['id'=>$project->id])); ?>" class="btn btn-primary">Edit</a>
              </div>
            </div>
          </form>
        </div>  
        <!-- /.tab-pane -->
      </div>
      <!-- /.tab-content -->
    </div>
    <!-- /.nav-tabs-custom -->
  </div>
  <!-- /.col -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.masterlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>