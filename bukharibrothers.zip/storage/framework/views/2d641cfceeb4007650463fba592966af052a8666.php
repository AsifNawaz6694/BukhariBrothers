<!DOCTYPE html>
<!--[if lt IE 7]>      
<html class="no-js lt-ie9 lt-ie8 lt-ie7">
   <![endif]-->
   <!--[if IE 7]>         
   <html class="no-js lt-ie9 lt-ie8">
      <![endif]-->
      <!--[if IE 8]>         
      <html class="no-js lt-ie9">
         <![endif]-->
         <!--[if gt IE 8]><!--> 
         <html class="no-js">
            <!--<![endif]-->
            <head>
               <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
               <meta name="description" content="Meghna One page parallax responsive HTML Template ">
               <meta name="author" content="Muhammad Morshed">
               <title>BukhariBrothers</title>
               <!-- Mobile Specific Meta
                  ================================================== -->
               <meta name="viewport" content="width=device-width, initial-scale=1">
               <!-- Favicon -->
               <!-- <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" /> -->
               <!-- CSS
                  ================================================== -->
               <!-- Fontawesome Icon font -->
               <link rel="stylesheet" href="<?php echo e(asset('public/frontend_assets/plugins/themefisher-font/style.css')); ?>">
               <!-- bootstrap.min css -->
               <link rel="stylesheet" href="<?php echo e(asset('public/frontend_assets/plugins/bootstrap/dist/css/bootstrap.min.css')); ?>">
               <!-- Animate.css -->
               <link rel="stylesheet" href="<?php echo e(asset('public/frontend_assets/plugins/animate-css/animate.css')); ?>">
               <!-- Magnific popup css -->
               <link rel="stylesheet" href="<?php echo e(asset('public/frontend_assets/plugins/magnific-popup/dist/magnific-popup.css')); ?>">
               <!-- Slick Carousel -->
               <link rel="stylesheet" href="<?php echo e(asset('public/frontend_assets/plugins/slick-carousel/slick/slick.css')); ?>">
               <link rel="stylesheet" href="<?php echo e(asset('public/frontend_assets/plugins/slick-carousel/slick/slick-theme.css')); ?>">
               <!-- Main Stylesheet -->
               <link rel="stylesheet" href="<?php echo e(asset('public/frontend_assets/css/style.css')); ?>">
            </head>
            
                <?php echo $__env->make('general_partials.error_section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <body id="body" data-spy="scroll" data-target=".navbar" data-offset="50">
               <!--
           
                  ==================================== -->
               <!--
                  Welcome Slider
                  ==================================== -->
               <?php echo $__env->make('front.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

               <!--
                  End Fixed Navigation
                  ==================================== -->
               <!--
                  Start About Section
                  ==================================== -->
               <section class="bg-one about section">
                  <div class="container">
                     <div class="row">
                        <!-- section title -->
                        <div class="title text-center wow fadeIn" data-wow-duration="1500ms" >
                           <h2>About <span class="color">Us</span> </h2>
                           <div class="border"></div>
                        </div>
                        <!-- /section title -->
                        <!-- About item -->
                        
                        <!-- End About item -->
                        <!-- About item -->
                        
                        <!-- End About item -->
                        <!-- About item -->					
                        
                        <!-- End About item -->
                     </div>
                     <!-- End row -->
                  </div>
                  <!-- End container -->
               </section>
               <!-- End section -->
               <section class="section about-2 padding-0 bg-dark" id="about">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-md-6 padding-0 ">
                           <img class="img-responsive" src="<?php echo e(asset('public/frontend_assets/images/about/about-business-man.jpg')); ?>" alt="">
                        </div>
                        <div class="col-md-6">
                           <div class="content-block">
                              <h2><?php echo e($about['heading']); ?>.</h2>
                              <p><?php echo e($about['description']); ?></p>
                             
                             
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <!--
                  Start Call To Action
                  ==================================== -->
              
               <!-- End section -->
               <!-- Start Services Section
                  ==================================== -->
               <section id="services" class="bg-one section">
                  <div class="container">
                     <div class="row">
                        <!-- section title -->
                        <div class="title text-center wow fadeIn" data-wow-duration="500ms">
                           <h2>Our <span class="color">Services</span></h2>
                           <div class="border"></div>
                        </div>
                        <!-- /section title -->
                        <!-- Single Service Item -->
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="col-md-4 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="500ms">
                           <div class="service-block text-center">
                              <div class="service-icon text-center">
                                 <i class="tf-globe"></i>
                              </div>
                              <h3><?php echo e($service->title); ?></h3>
                              <p><?php echo e($service->description); ?></p>
                           </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- End Single Service Item -->
                     </div>
                     <!-- End row -->
                  </div>
                  <!-- End container -->
               </section>
               <!-- End section -->
               <!-- Start Team Skills
                  =========================================== -->
               <section id="team-skills" class="parallax-section section section-bg overly">
                  <div class="container">
                     <div class="row" >
                        <!-- section title -->
                        <div class="col-md-12">
                           <div class="title text-center">
                              <h2> <span class="color">Careers</span></h2>
                              <div class="border"></div>
                           </div>
                        </div>
                        <!-- /section title -->
                     </div>
                     <!-- End row -->
                     <div class="row">
                        <div class="col-md-6">
                           <h2>We’ve skilled in wide range of web and <br>
                              Other digital market tools.
                           </h2>
                           <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis magni explicabo cum aperiam recusandae sunt accusamus totam. Quidem quos fugiat sapiente numquam accusamus quas hic, itaque in libero reiciendis tempora!</p>
                        </div>
                        <div class="col-md-6">
                           <!-- Contact Form -->
                           <form id="contact-form" method="post" action="<?php echo e(route('career_post')); ?>" role="form" enctype="multipart/form-data">
                              <?php echo e(csrf_field()); ?>

                              <div class="form-group">
                                 <input type="text" placeholder="Your Name" class="form-control" name="name" id="name">
                              </div>
                              <div class="form-group">
                                 <input type="email" placeholder="Your Email" class="form-control" name="email" id="email">
                              </div>
                              <div class="form-group">
                                 <input type="text" placeholder="Position" class="form-control" name="position" id="subject">
                              </div>
                              <label>Upload Your resue Here</label>
                              <div class="form-group">
                                  <div class="col-sm-10">
                                      <div class="row">
                                          <div class="col-sm-6">
                                              <input type="file" name="resume" class="filePath" data-class="img1">
                                          </div>
                                          <div class="col-sm-6">
                                              <a href="" class="img1" download>
                                                  <img src="" class="img1" width="50px"/>
                                                  <span class="img1" style="display:none; color:#FF0000;">
                                                  File Download
                                                  </span>
                                              </a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <br>
                              <br>
                              <div id="mail-success" class="success">
                                 Thank you. The Mailman is on His Way :)
                              </div>
                              <div id="mail-fail" class="error">
                                 Sorry, don't know what happened. Try later :(
                              </div>
                              <div id="cf-submit">
                                 <input type="submit" id="contact-submit" class="btn btn-transparent" value="Submit">
                              </div>
                           </form>
                        
                        <!-- ./End Contact Form -->
                           
                        </div>
                     </div>
                  </div>
                  <!-- End container -->
               </section>
               <!-- End section -->
               <!-- Start Portfolio Section
                  =========================================== -->
               <section class="portfolio section" id="resources">
                  <div class="container">
                     <div class="row " >
                        <div class="col-lg-12">
                           <!-- section title -->
                           <div class="title text-center">
                              <h2>Our <span class="color">Resources</span></h2>
                              <div class="border"></div>
                           </div>
                           <!-- /section title -->
                        </div>
                        <!-- /end col-lg-12 -->
                     </div>
                     <!-- end row -->
                   
                     <div class="row portfolio-items-wrapper">
                        <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mix col-md-4 design">
                           <div class="portfolio-block">
                              <img class="img-responsive" src="<?php echo e(asset('public/storage/resources-images/' . $resource->image)); ?>" alt="">
                              <div class="caption">
                                 <a class="search-icon image-popup" data-effect="mfp-with-zoom" href="" data-lightbox="image-1">
                                 <i class="tf-ion-android-search"></i>
                                 </a>
                                 <h4><a href=""><?php echo e($resource->title); ?></a></h4>
                                 <p><?php echo e($resource->description); ?></p>
                              </div>
                           </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                     </div>
                  </div>
                  <!-- end container -->
               </section>
               <!-- End section -->
               <!--
                  Start Counter Section
                  ==================================== -->
               <section id="counter" class="parallax-section bg-1 section overly">
                  <div class="container">
                     <div class="row">
                        <!-- first count item -->
                        <div class="col-md-4 col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms">
                           <div class="counters-item">
                              <i class="tf-ion-android-happy"></i>
                              <span data-speed="3000" data-to="320"><?php echo e($users_count); ?></span>
                              <h3>Staff Members</h3>
                           </div>
                        </div>
                        <!-- end first count item -->
                        <!-- second count item -->
                        
                        <!-- end second count item -->
                        <!-- third count item -->
                        <div class="col-md-4 col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="400ms">
                           <div class="counters-item">
                              <i class="tf-ion-thumbsup"></i>
                              <span data-speed="3000" data-to="95"><?php echo e($resources_count); ?></span>
                              <h3>Total Resources</h3>
                           </div>
                        </div>
                        <!-- end third count item -->
                        <!-- fourth count item -->
                        <div class="col-md-4 col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="600ms">
                           <div class="counters-item kill-margin-bottom">
                              <i class="tf-ion-coffee"></i>
                              <span data-speed="3000" data-to="2500"><?php echo e($services_count); ?></span>
                              <h3>Number Of Services</h3>
                           </div>
                        </div>
                        <!-- end fourth count item -->
                     </div>
                     <!-- end row -->
                  </div>
                  <!-- end container -->
               </section>
               <!-- end section -->
               <!-- 
                  Start Our Team
                  =========================================== -->
               <section id="our-team" class="section">
                  <div class="container">
                     <div class="row">
                        <!-- section title -->
                        <div class="title text-center wow fadeInUp" data-wow-duration="500ms">
                           <h2>Our <span class="color">Team</span></h2>
                           <div class="border"></div>
                        </div>
                        <!-- /section title -->
                        <!-- team member -->
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6 col-xs-12  wow fadeInDown" data-wow-duration="500ms">
                           
                           <div class="team-member">
                              <div class="member-photo">
                                 <!-- member photo -->
                                 <img class="img-responsive" src="<?php echo e(asset('public/storage/profile-pictures/' . $user->profile_pic)); ?>" alt="Meghna">
                                 <!-- /member photo -->
                                 <!-- member social profile -->
                                 
                                 <!-- /member social profile -->
                              </div>
                              <!-- member name & designation -->
                              <div class="member-meta">
                                 <h4><?php echo e($user->name); ?></h4>
                                 <span><?php echo e($user->designation); ?></span>
                                 <p><?php echo e($user->about); ?></p>
                              </div>
                              <!-- /member name & designation -->
                              <!-- /about member -->
                           </div>
                        </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- end team member -->
                        <!-- team member -->
                        
                        <!-- end team member -->
                     </div>
                     <!-- End row -->
                  </div>
                  <!-- End container -->
               </section>
               <!-- End section -->
               <!-- Start Pricing section
                  =========================================== -->
               
               <!-- End section -->
               <!-- Start Testimonial
                  =========================================== -->
             
               <!-- End Section -->
               <!--
                  Start Blog Section
                  =========================================== -->
               <section id="projects" class="section">
                  <div class="container">
                     <div class="row">
                        <!-- section title -->
                        <div class="title text-center wow fadeInDown">
                           <h2> Latest <span class="color">Projects</span></h2>
                           <div class="border"></div>
                        </div>
                        <!-- /section title -->
                        <div class="clearfix">
                           <!-- single blog post -->
                           <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <article class="col-md-4 col-sm-6 col-xs-12 clearfix wow fadeInUp" data-wow-duration="500ms">
                                 <div class="post-block">
                                    <div class="media-wrapper">
                                       <img src="<?php echo e(asset('public/storage/project-images/' . $project->image)); ?>" alt="amazing caves coverimage" class="img-responsive">
                                    </div>
                                    <div class="content">
                                       <h3><a href=""><?php echo e($project->title); ?></a></h3>
                                       <p><?php echo e($project->description); ?>.</p>
                                       
                                    </div>
                                 </div>
                              </article>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <!-- /single blog post -->                          
                        </div>
                        <di
                     </div>
                     <!-- end row -->
                  </div>
                  <!-- end container -->
               </section>
               <!-- end section -->
               <!-- Srart Contact Us
                  =========================================== -->		
               <section id="contact-us" class="contact-us section-bg">
                  <div class="container">
                     <div class="row">
                        <!-- section title -->
                        <div class="title text-center wow fadeIn" data-wow-duration="500ms">
                           <h2>Get In <span class="color">Touch</span></h2>
                           <div class="border"></div>
                        </div>
                        <!-- /section title -->
                        <!-- Contact Details -->
                        <div class="contact-info col-md-6 wow fadeInUp" data-wow-duration="500ms">
                           <h3>Contact Details</h3>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam, vero, provident, eum eligendi blanditiis ex explicabo vitae nostrum facilis asperiores dolorem illo officiis ratione vel fugiat dicta laboriosam labore adipisci.</p>
                           <div class="contact-details">
                              <div class="con-info clearfix">
                                 <i class="tf-map-pin"></i>
                                 <span>Khaja Road, Bayzid, Chittagong, Bangladesh</span>
                              </div>
                              <div class="con-info clearfix">
                                 <i class="tf-ion-ios-telephone-outline"></i>
                                 <span>Phone: +880-31-000-000</span>
                              </div>
                              <div class="con-info clearfix">
                                 <i class="tf-ion-iphone"></i>
                                 <span>Fax: +880-31-000-000</span>
                              </div>
                              <div class="con-info clearfix">
                                 <i class="tf-ion-ios-email-outline"></i>
                                 <span>Email: hello@meghna.com</span>
                              </div>
                           </div>
                        </div>
                        <!-- / End Contact Details -->
                        <!-- Contact Form -->
                        <div class="contact-form col-md-6 wow fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                           <form id="contact-form" method="post" action="<?php echo e(route('contact_post')); ?>" role="form">
                              <?php echo e(csrf_field()); ?>

                              <div class="form-group">
                                 <input type="text" placeholder="Your Name" class="form-control" name="name" id="name">
                              </div>
                              <div class="form-group">
                                 <input type="email" placeholder="Your Email" class="form-control" name="email" id="email">
                              </div>
                              <div class="form-group">
                                 <input type="text" placeholder="Subject" class="form-control" name="contact_subject" id="subject">
                              </div>
                              <div class="form-group">
                                 <textarea rows="6" placeholder="Message" class="form-control" name="contact_message" id="message_contact"></textarea>	
                              </div>
                              <div id="mail-success" class="success">
                                 Thank you. The Mailman is on His Way :)
                              </div>
                              <div id="mail-fail" class="error">
                                 Sorry, don't know what happened. Try later :(
                              </div>
                              <div id="cf-submit">
                                 <input type="submit" id="contact-submit" class="btn btn-transparent" value="Submit">
                              </div>
                           </form>
                        </div>
                        <!-- ./End Contact Form -->
                     </div>
                     <!-- end row -->
                  </div>
                  <!-- end container -->
                  <!-- Google Map -->
                  
                  <!-- /Google Map -->
               </section>
               <!-- end section -->
               <!-- end Contact Area
                  ========================================== -->
              <?php echo $__env->make('front.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               <div id="scroll-up">
                  up
               </div>
               <!-- 
                  Essential Scripts
                  =====================================-->
               <!-- Main jQuery -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/jquery/dist/jquery.min.js')); ?>"></script>
               <!-- Bootstrap 3.1 -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
               <!-- Slick Carousel -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/slick-carousel/slick/slick.min.js')); ?>"></script>
               <!-- Portfolio Filtering -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/mixitup/dist/mixitup.min.js')); ?>"></script>
               <!-- Smooth Scroll -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/smooth-scroll/dist/js/smooth-scroll.min.js')); ?>"></script>
               <!-- Magnific popup -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>
               <!-- Google Map API -->
               <script type="text/javascript"  src="<?php echo e(asset('http://maps.google.com/maps/api/js?sensor=false')); ?>"></script>
               <!-- Sticky Nav -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/Sticky/jquery.sticky.js')); ?>"></script>
               <!-- Number Counter Script -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/count-to/jquery.countTo.js')); ?>"></script>
               <!-- wow.min Script -->
               <script type="text/javascript" src="<?php echo e(asset('plugins/wow/dist/wow.min.js')); ?>"></script>
               <!-- Custom js -->
               <script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
            </body>
         </html>