<!DOCTYPE>
<html>
<head>
    <title>Career Email</title>
</head>
 
<body>

<h2>Name<b></b></h2>
<p> <?php echo e($data['name']); ?> </p>
<br>
<h2>Position<b></b></h2>
<p> <?php echo e($data['position']); ?> </p>
<br>
<h2>Subject<b></b></h2>
<p> <?php echo e($data['name']); ?>  has showed interest to work with BukhariBrothers</p>
<br>

</body>
 
</html>