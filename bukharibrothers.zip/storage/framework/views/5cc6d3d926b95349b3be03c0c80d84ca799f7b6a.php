 <footer id="footer" class="bg-one">
                  <div class="container">
                     <div class="row wow fadeInUp" data-wow-duration="500ms">
                        <div class="col-lg-12">
                           <!-- Footer Social Links -->
                           <div class="social-icon">
                              <ul class="list-inline">
                                 <li><a href="#"><i class="tf-ion-social-facebook"></i></a></li>
                                 <li><a href="#"><i class="tf-ion-social-twitter"></i></a></li>
                                 <li><a href="#"><i class="tf-ion-social-google-outline"></i></a></li>
                                 <li><a href="#"><i class="tf-ion-social-youtube"></i></a></li>
                                 <li><a href="#"><i class="tf-ion-social-linkedin"></i></a></li>
                                 <li><a href="#"><i class="tf-ion-social-dribbble-outline"></i></a></li>
                                 <li><a href="#"><i class="tf-ion-social-pinterest-outline"></i></a></li>
                              </ul>
                           </div>
                           <!--/. End Footer Social Links -->
                           <!-- copyright -->
                           <div class="copyright text-center">
                              <a href="index.html">
                                 <!-- <img src="images/logo-meghna.png" alt="Meghna" />  -->
                                 <svg width="40px" height="40px" viewBox="0 0 45 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                       <g id="Group" transform="translate(2.000000, 2.000000)" stroke="#57CBCC" stroke-width="3">
                                          <ellipse id="Oval" cx="20.5" cy="20" rx="20.5" ry="20"></ellipse>
                                          <path d="M6,7 L33.5,34.5" id="Line-2" stroke-linecap="square"></path>
                                          <path d="M21,20 L34,7" id="Line-3" stroke-linecap="square"></path>
                                       </g>
                                    </g>
                                 </svg>
                              </a>
                              <br/>
                              <p>
                                 Design And Developed by <a href="http://www.themefisher.com"> Themefisher Team</a>. Copyright &copy; <script>document.write(new Date().getFullYear())</script>. All Rights Reserved.
                                 <br>Get More<a href="https://themefisher.com/free-bootstrap-templates/" target="_blank">Free Bootstrap Templates</a>
                              </p>
                           </div>
                           <!-- /copyright -->
                        </div>
                        <!-- end col lg 12 -->
                     </div>
                     <!-- end row -->
                  </div>
                  <!-- end container -->
               </footer>
               <!-- end footer -->