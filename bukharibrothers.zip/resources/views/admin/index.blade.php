@extends('admin.masterlayout')
@section('content')

<!-- <div class="container"> -->
	<div class="row">
		<div class="col-md-12">
			<div id="chartContainer" style="height: 300px; width: 100%;"></div>
		</div>
	</div><br>
	<div class="row">
		<div class="col-md-12">
			<div id="chartContainer_order" style="height: 300px; width: 100%;"></div>
		</div>
	</div>
@endsection