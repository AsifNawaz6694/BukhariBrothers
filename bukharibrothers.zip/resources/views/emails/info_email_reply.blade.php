<!DOCTYPE>
<html>
<head>
    <title>Contact Us Email Reply</title>
</head>
 
<body>

<h2>Name<b></b></h2>
<p> {{ $data['name'] }} </p>
<br>
<h2>Subject<b></b></h2>
<p> {{ $data['contact_subject'] }} </p>
<br>
<h2>Message<b></b></h2>
<p> {{ $data['contact_message'] }} </p>
<br>

</body>
 
</html>