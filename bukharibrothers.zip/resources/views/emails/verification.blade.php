<!DOCTYPE html>
<html>
<head>
    <title>Query Email</title>
</head>
 
<body>
<h2>Title<b></b></h2>
{{$user->title}}
<br/>
<h3>Description</h3>
{{$user->description}}
<br>
	By verifying your email address  help us secure your Music Voting account.
</body>
 
</html>